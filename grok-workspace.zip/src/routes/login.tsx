import { useState } from "react";
import { createFileRoute, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Mark } from "@/components/mark";
import { Splash, Stage } from "@/components/shell";

export const Route = createFileRoute("/login")({ component: Login });

function GoogleMark() {
  return (
    <svg viewBox="0 0 48 48" className="size-5" aria-hidden>
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 8 3.1l5.7-5.7C34.2 6.1 29.4 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 12 24 12c3.1 0 5.8 1.2 8 3.1l5.7-5.7C34.2 6.1 29.4 4 24 4 16.3 4 9.6 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 10-2 13.6-5.2l-6.3-5.3C29.3 35.1 26.8 36 24 36c-5.3 0-9.7-3.4-11.3-8.1l-6.5 5C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-1.1 3.2-3.5 5.7-6.6 7.1l6.3 5.3C37.4 38.4 44 32.5 44 24c0-1.3-.1-2.7-.4-3.5z" />
    </svg>
  );
}

function Login() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <Stage>
        <Splash />
      </Stage>
    );
  }
  if (user) return <Navigate to="/" />;
  return (
    <Stage>
      <LoginPanel />
    </Stage>
  );
}

function LoginPanel() {
  const [pending, setPending] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const google = GROK_PROVIDERS.find((provider) => provider.providerId === "grok-google");
  const others = GROK_PROVIDERS.filter((provider) => provider.providerId !== "grok-google");

  async function start(providerId: string) {
    setError(null);
    setPending(providerId);
    try {
      await signIn(providerId, { callbackURL: "/" });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not sign in.");
      setPending(null);
    }
  }

  return (
    <div className="flex flex-1 flex-col justify-between px-6 py-10">
      <div className="flex items-center gap-3 md:hidden">
        <Mark />
        <span className="text-lg font-semibold tracking-tight">Cove</span>
      </div>
      <div className="mx-auto w-full max-w-sm">
        <h1 className="text-3xl font-semibold tracking-tight text-balance md:text-4xl">
          Sign in with Gmail.
        </h1>
        <p className="mt-3 text-pretty text-muted">
          Use the Google account you already have. After that, choose the username people will search for.
        </p>
        <div className="mt-8 space-y-3">
          {google && (
            <button
              type="button"
              disabled={pending !== null}
              onClick={() => void start(google.providerId)}
              className="flex h-12 w-full items-center justify-center gap-3 rounded-2xl bg-fg text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-60"
            >
              <GoogleMark />
              {pending === google.providerId ? "Opening Google…" : "Continue with Gmail"}
            </button>
          )}
          {others.map((provider) => (
            <button
              key={provider.providerId}
              type="button"
              disabled={pending !== null}
              onClick={() => void start(provider.providerId)}
              className="flex h-12 w-full items-center justify-center rounded-2xl border border-line bg-surface text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-60"
            >
              {pending === provider.providerId ? "Opening…" : `Continue with ${provider.label}`}
            </button>
          ))}
          {error && <p className="text-sm text-primary">{error}</p>}
        </div>
      </div>
      <p className="text-center text-xs text-muted">Chats stay between the people in them.</p>
    </div>
  );
}
