import { useEffect, useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { openConversation, requestFriend, searchPeople, type Person } from "@/lib/chat.functions";
import { errorText } from "@/lib/format";
import { Avatar } from "@/components/avatar";
import { PageHeader, RequireUser } from "@/components/shell";

export const Route = createFileRoute("/search")({ component: SearchPage });

function SearchPage() {
  return (
    <RequireUser>
      <SearchScreen />
    </RequireUser>
  );
}

function SearchScreen() {
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(query.trim()), 180);
    return () => clearTimeout(timer);
  }, [query]);
  const people = useQuery({
    queryKey: ["people", debounced],
    queryFn: () => searchPeople({ data: debounced }),
    refetchInterval: 8000,
  });
  return (
    <div>
      <PageHeader kicker="Directory" title="Search" />
      <div className="px-5 pb-3">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Username or display name"
          autoCapitalize="none"
          autoCorrect="off"
          className="h-12 w-full rounded-2xl border border-line bg-surface px-4 text-fg outline-none placeholder:text-muted"
        />
      </div>
      {people.isPending && <p className="px-5 py-6 text-sm text-muted">Looking through Cove…</p>}
      {people.data && people.data.length === 0 && (
        <p className="px-5 py-10 text-center text-sm text-muted">No one matches that.</p>
      )}
      {!debounced && people.data && people.data.length > 0 && (
        <p className="px-5 pb-1 text-xs font-semibold tracking-widest text-muted uppercase">On Cove</p>
      )}
      <ul>
        {people.data?.map((person) => (
          <PersonResult key={person.userId} person={person} />
        ))}
      </ul>
    </div>
  );
}

function PersonResult({ person }: { person: Person }) {
  const navigate = useNavigate();
  const client = useQueryClient();
  const add = useMutation({
    mutationFn: () => requestFriend({ data: person.userId }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ["people"] });
      void client.invalidateQueries({ queryKey: ["notifications"] });
    },
  });
  const open = useMutation({
    mutationFn: () => openConversation({ data: person.userId }),
    onSuccess: (result) => {
      void navigate({ to: "/c/$conversationId", params: { conversationId: String(result.conversationId) } });
    },
  });
  const label =
    person.relation === "friends" ? "Message" : person.relation === "outgoing" ? "Requested" : person.relation === "incoming" ? "Accept" : "Add";
  return (
    <li className="flex items-center gap-3 px-5 py-3">
      <Link to="/u/$username" params={{ username: person.username }} className="flex min-w-0 flex-1 items-center gap-3">
        <Avatar
          userId={person.userId}
          name={person.displayName}
          hue={person.hue}
          url={person.avatarUrl}
          rev={person.avatarRev}
          online={person.online}
        />
        <span className="min-w-0">
          <span className="block truncate font-semibold">{person.displayName}</span>
          <span className="block truncate text-sm text-muted">@{person.username}</span>
        </span>
      </Link>
      <button
        type="button"
        disabled={add.isPending || open.isPending || person.relation === "outgoing"}
        onClick={() => {
          if (person.relation === "friends") open.mutate();
          else add.mutate();
        }}
        className="h-10 shrink-0 rounded-2xl bg-primary px-3 text-sm font-semibold text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50"
      >
        {label}
      </button>
      {(add.isError || open.isError) && (
        <span className="sr-only">{errorText(add.error ?? open.error)}</span>
      )}
    </li>
  );
}
