import { useEffect, useRef, useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ImagePlus, Send, X } from "lucide-react";
import {
  getMessageImage,
  getThread,
  markRead,
  sendMessage,
  setTyping,
  unblockPerson,
} from "@/lib/chat.functions";
import { dayKey, errorText, formatDay, formatWhen } from "@/lib/format";
import { compressImage } from "@/lib/images";
import { Avatar } from "@/components/avatar";
import { RequireUser } from "@/components/shell";

export const Route = createFileRoute("/c/$conversationId")({ component: ThreadPage });

function ThreadPage() {
  const { conversationId } = Route.useParams();
  return (
    <RequireUser immersive>
      <Thread conversationId={Number(conversationId)} />
    </RequireUser>
  );
}

function Thread({ conversationId }: { conversationId: number }) {
  const client = useQueryClient();
  const thread = useQuery({
    queryKey: ["thread", conversationId],
    queryFn: () => getThread({ data: conversationId }),
    refetchInterval: 1000,
  });
  const scroller = useRef<HTMLDivElement>(null);
  const count = thread.data?.messages.length ?? 0;
  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTop = node.scrollHeight;
  }, [count, thread.data?.typing]);
  useEffect(() => {
    if (!thread.isSuccess || !thread.data) return;
    void markRead({ data: conversationId }).then(() => {
      void client.invalidateQueries({ queryKey: ["conversations"] });
      void client.invalidateQueries({ queryKey: ["notifications"] });
    });
  }, [conversationId, count, client, thread.isSuccess]);

  const data = thread.data;
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="flex items-center gap-2 border-b border-line px-2 py-2">
        <Link to="/" aria-label="Back to chats" className="grid size-11 place-items-center rounded-full">
          <ArrowLeft className="size-5" />
        </Link>
        {data && (
          <Link
            to="/u/$username"
            params={{ username: data.partner.username }}
            className="flex min-w-0 flex-1 items-center gap-3"
          >
            <Avatar
              userId={data.partner.userId}
              name={data.partner.displayName}
              hue={data.partner.hue}
              url={data.partner.avatarUrl}
              rev={data.partner.avatarRev}
              online={data.partner.online}
              size="sm"
            />
            <span className="min-w-0">
              <span className="block truncate font-semibold">{data.partner.displayName}</span>
              <span className="block truncate text-xs text-muted">
                {data.typing ? "Typing…" : data.partner.online === true ? "Online" : `@${data.partner.username}`}
              </span>
            </span>
          </Link>
        )}
      </header>
      <div ref={scroller} className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4">
        {thread.isPending && <p className="text-sm text-muted">Loading messages…</p>}
        {data === null && <p className="py-16 text-center text-sm text-muted">This conversation isn't available.</p>}
        {data?.messages.map((message, index) => {
          const mine = message.senderId !== data.partner.userId;
          const previous = data.messages[index - 1];
          const showDay = !previous || dayKey(previous.createdAt) !== dayKey(message.createdAt);
          const lastOwn = [...data.messages].reverse().find((item) => item.senderId !== data.partner.userId);
          return (
            <div key={message.id}>
              {showDay && (
                <p className="py-3 text-center text-xs font-medium text-muted">{formatDay(message.createdAt)}</p>
              )}
              <div className={mine ? "flex justify-end" : "flex justify-start"}>
                <div
                  className={
                    mine
                      ? "max-w-xs rounded-2xl rounded-br-md bg-primary px-3 py-2 text-primary-fg"
                      : "max-w-xs rounded-2xl rounded-bl-md bg-elevated px-3 py-2 text-fg"
                  }
                >
                  {message.hasImage && <Photo id={message.id} mine={mine} />}
                  {message.body && <MessageText text={message.body} mine={mine} />}
                  <p className={mine ? "mt-1 text-right text-xs text-primary-fg/80 tabular-nums" : "mt-1 text-xs text-muted tabular-nums"}>
                    {formatWhen(message.createdAt)}
                  </p>
                </div>
              </div>
              {mine && lastOwn?.id === message.id && (
                <p className="mt-1 text-right text-xs text-muted">
                  {receipt(message.createdAt, message.deliveredAt, data.partnerReadAt)}
                </p>
              )}
            </div>
          );
        })}
        {data?.typing && (
          <p className="flex items-center gap-1 text-sm text-muted">
            <span className="typing-dot size-1.5 rounded-full bg-muted" />
            <span className="typing-dot size-1.5 rounded-full bg-muted" />
            <span className="typing-dot size-1.5 rounded-full bg-muted" />
          </p>
        )}
      </div>
      {data && <Composer threadId={conversationId} canSend={data.canSend} hint={data.sendHint} blocked={data.blockedByMe} partnerId={data.partner.userId} />}
    </div>
  );
}

function receipt(createdAt: string, deliveredAt: string | null, partnerReadAt: string | null): string {
  if (partnerReadAt && new Date(partnerReadAt).getTime() >= new Date(createdAt).getTime()) return "Seen";
  if (deliveredAt) return "Delivered";
  return "Sent";
}

function MessageText({ text, mine }: { text: string; mine: boolean }) {
  const parts = text.split(/(https?:\/\/[^\s]+)/g);
  return (
    <p className="text-sm break-words whitespace-pre-wrap">
      {parts.map((part, index) =>
        part.startsWith("http") ? (
          <a
            key={index}
            href={part}
            target="_blank"
            rel="noreferrer"
            className={mine ? "underline" : "text-primary underline"}
          >
            {part}
          </a>
        ) : (
          <span key={index}>{part}</span>
        ),
      )}
    </p>
  );
}

function Photo({ id, mine }: { id: number; mine: boolean }) {
  const photo = useQuery({
    queryKey: ["photo", id],
    queryFn: () => getMessageImage({ data: id }),
    staleTime: Infinity,
  });
  if (!photo.data) {
    return <div className={mine ? "mb-2 h-36 w-52 animate-pulse rounded-xl bg-primary-fg/20" : "mb-2 h-36 w-52 animate-pulse rounded-xl bg-line"} />;
  }
  return <img src={photo.data} alt="Photo" className="mb-2 max-h-64 w-full rounded-xl object-cover" />;
}

function Composer({
  threadId,
  canSend,
  hint,
  blocked,
  partnerId,
}: {
  threadId: number;
  canSend: boolean;
  hint: string | null;
  blocked: boolean;
  partnerId: string;
}) {
  const client = useQueryClient();
  const [text, setText] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const send = useMutation({
    mutationFn: (payload: { body: string; image: string | null }) =>
      sendMessage({ data: { conversationId: threadId, body: payload.body, image: payload.image } }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ["thread", threadId] });
      void client.invalidateQueries({ queryKey: ["conversations"] });
    },
    onError: (cause, payload) => {
      setText(payload.body);
      setImage(payload.image);
      setError(errorText(cause));
    },
  });
  useEffect(() => {
    if (!canSend) return;
    const typing = text.trim().length > 0 || Boolean(image);
    void setTyping({ data: { conversationId: threadId, typing } }).catch(() => undefined);
    if (!typing) return;
    const timer = setInterval(() => {
      void setTyping({ data: { conversationId: threadId, typing: true } }).catch(() => undefined);
    }, 2000);
    return () => {
      clearInterval(timer);
      void setTyping({ data: { conversationId: threadId, typing: false } }).catch(() => undefined);
    };
  }, [text, image, threadId, canSend]);

  const unblock = useMutation({
    mutationFn: () => unblockPerson({ data: partnerId }),
    onSuccess: () => void client.invalidateQueries({ queryKey: ["thread", threadId] }),
  });

  if (!canSend) {
    return (
      <div className="border-t border-line px-4 py-4">
        <p className="text-sm text-muted">{hint ?? "You can't message this person."}</p>
        {blocked && (
          <button
            type="button"
            onClick={() => unblock.mutate()}
            className="mt-3 h-10 rounded-2xl bg-primary px-4 text-sm font-semibold text-primary-fg"
          >
            Unblock
          </button>
        )}
      </div>
    );
  }

  return (
    <form
      className="pb-safe border-t border-line px-3 py-3"
      onSubmit={(event) => {
        event.preventDefault();
        const body = text;
        const photo = image;
        if (!body.trim() && !photo) return;
        setText("");
        setImage(null);
        setError(null);
        send.mutate({ body, image: photo });
      }}
    >
      {image && (
        <div className="relative mb-2 w-24">
          <img src={image} alt="Attachment preview" className="h-24 w-24 rounded-xl object-cover" />
          <button
            type="button"
            aria-label="Remove photo"
            onClick={() => setImage(null)}
            className="absolute -top-2 -right-2 grid size-7 place-items-center rounded-full bg-fg text-bg"
          >
            <X className="size-3.5" />
          </button>
        </div>
      )}
      <div className="flex items-end gap-2">
        <button
          type="button"
          aria-label="Add photo"
          onClick={() => fileRef.current?.click()}
          className="grid size-11 shrink-0 place-items-center rounded-full bg-elevated"
        >
          <ImagePlus className="size-5" />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            void compressImage(file, 960, 0.62)
              .then((data) => {
                if (data.length > 280_000) {
                  setError("That photo is still too large.");
                  return;
                }
                setImage(data);
                setError(null);
              })
              .catch((cause: unknown) => setError(errorText(cause)));
          }}
        />
        <textarea
          value={text}
          rows={1}
          maxLength={2000}
          placeholder="Message"
          onChange={(event) => setText(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault();
              event.currentTarget.form?.requestSubmit();
            }
          }}
          className="max-h-28 min-h-11 flex-1 resize-none rounded-2xl border border-line bg-surface px-4 py-3 text-sm outline-none"
        />
        <button
          type="submit"
          aria-label="Send"
          disabled={send.isPending || (!text.trim() && !image)}
          className="grid size-11 shrink-0 place-items-center rounded-full bg-primary text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40"
        >
          <Send className="size-4" />
        </button>
      </div>
      {error && <p className="mt-2 px-1 text-xs text-primary">{error}</p>}
    </form>
  );
}
