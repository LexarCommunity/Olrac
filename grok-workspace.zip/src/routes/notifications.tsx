import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  listNotifications,
  markNotificationsRead,
  openConversation,
  respondFriend,
  type Notice,
} from "@/lib/chat.functions";
import { errorText, formatWhen } from "@/lib/format";
import { Avatar } from "@/components/avatar";
import { Empty, PageHeader, RequireUser } from "@/components/shell";

export const Route = createFileRoute("/notifications")({ component: NotificationsPage });

function NotificationsPage() {
  return (
    <RequireUser>
      <Notifications />
    </RequireUser>
  );
}

function Notifications() {
  const client = useQueryClient();
  const notes = useQuery({
    queryKey: ["notifications"],
    queryFn: () => listNotifications(),
    refetchInterval: 2000,
  });
  const markAll = useMutation({
    mutationFn: () => markNotificationsRead({ data: null }),
    onSuccess: () => void client.invalidateQueries({ queryKey: ["notifications"] }),
  });
  const unread = notes.data?.unread ?? 0;
  return (
    <div>
      <PageHeader
        kicker="Activity"
        title="Notifications"
        action={
          unread > 0 ? (
            <button
              type="button"
              onClick={() => markAll.mutate()}
              className="text-sm font-semibold text-primary"
            >
              Mark read
            </button>
          ) : null
        }
      />
      {notes.data && notes.data.items.length === 0 && (
        <Empty
          title="You're caught up"
          body="Friend requests, accepts, and new messages land here."
        />
      )}
      <ul>
        {notes.data?.items.map((notice) => (
          <NoticeRow key={notice.id} notice={notice} />
        ))}
      </ul>
    </div>
  );
}

function copyFor(notice: Notice): string {
  if (notice.kind === "friend_request") return "sent you a friend request";
  if (notice.kind === "friend_accepted") return "accepted your friend request";
  return "sent you a message";
}

function NoticeRow({ notice }: { notice: Notice }) {
  const client = useQueryClient();
  const navigate = useNavigate();
  const refresh = () => {
    void client.invalidateQueries({ queryKey: ["notifications"] });
    void client.invalidateQueries({ queryKey: ["people"] });
    void client.invalidateQueries({ queryKey: ["conversations"] });
  };
  const respond = useMutation({
    mutationFn: (accept: boolean) =>
      respondFriend({ data: { friendshipId: notice.friendshipId ?? 0, accept } }),
    onSuccess: refresh,
  });
  const open = useMutation({
    mutationFn: async () => {
      await markNotificationsRead({ data: notice.id });
      if (notice.conversationId) return notice.conversationId;
      const chat = await openConversation({ data: notice.actor.userId });
      return chat.conversationId;
    },
    onSuccess: (conversationId) => {
      refresh();
      void navigate({ to: "/c/$conversationId", params: { conversationId: String(conversationId) } });
    },
  });
  const pendingRequest = notice.kind === "friend_request" && notice.friendshipStatus === "pending";
  return (
    <li className={notice.read ? "px-5 py-3" : "bg-surface px-5 py-3"}>
      <div className="flex gap-3">
        <Link to="/u/$username" params={{ username: notice.actor.username }}>
          <Avatar
            userId={notice.actor.userId}
            name={notice.actor.displayName}
            hue={notice.actor.hue}
            url={notice.actor.avatarUrl}
            rev={notice.actor.avatarRev}
            online={notice.actor.online}
            size="sm"
          />
        </Link>
        <div className="min-w-0 flex-1">
          <button
            type="button"
            onClick={() => {
              if (notice.kind === "message" || notice.kind === "friend_accepted") open.mutate();
            }}
            className="block w-full text-left"
          >
            <p className="text-sm text-pretty">
              <span className="font-semibold">{notice.actor.displayName}</span> {copyFor(notice)}
            </p>
            <p className="mt-1 text-xs text-muted tabular-nums">{formatWhen(notice.createdAt)}</p>
          </button>
          {pendingRequest && (
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                disabled={respond.isPending}
                onClick={() => respond.mutate(true)}
                className="h-10 rounded-2xl bg-primary px-4 text-sm font-semibold text-primary-fg active:scale-[0.96]"
              >
                Accept
              </button>
              <button
                type="button"
                disabled={respond.isPending}
                onClick={() => respond.mutate(false)}
                className="h-10 rounded-2xl border border-line px-4 text-sm font-semibold active:scale-[0.96]"
              >
                Decline
              </button>
            </div>
          )}
          {notice.kind === "friend_request" && notice.friendshipStatus === "accepted" && (
            <p className="mt-2 text-xs font-medium text-primary">Accepted</p>
          )}
          {notice.kind === "friend_request" && notice.friendshipStatus === "declined" && (
            <p className="mt-2 text-xs font-medium text-muted">Declined</p>
          )}
          {respond.isError && <p className="mt-2 text-xs text-primary">{errorText(respond.error)}</p>}
        </div>
      </div>
    </li>
  );
}
