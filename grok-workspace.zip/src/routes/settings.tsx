import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, useSyncExternalStore, type ReactNode } from "react";
import { signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import {
  ensureProfile,
  listBlocked,
  savePrivacy,
  saveProfile,
  unblockPerson,
  type MessagePolicy,
  type OnlinePolicy,
} from "@/lib/chat.functions";
import { errorText } from "@/lib/format";
import { compressImage } from "@/lib/images";
import { Avatar } from "@/components/avatar";
import { PageHeader, RequireUser } from "@/components/shell";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  return (
    <RequireUser>
      <Settings />
    </RequireUser>
  );
}

const subscribe = () => () => {};

function Settings() {
  const client = useQueryClient();
  const me = useQuery({
    queryKey: ["me"],
    queryFn: () => ensureProfile(),
  });
  const blocked = useQuery({
    queryKey: ["blocked"],
    queryFn: () => listBlocked(),
  });
  const profile = me.data;
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState<{ action: "keep" | "set" | "clear"; url: string | null }>({
    action: "keep",
    url: null,
  });
  const [cover, setCover] = useState<{ action: "keep" | "set" | "clear"; url: string | null }>({
    action: "keep",
    url: null,
  });
  const [ready, setReady] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [fileError, setFileError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const gateSession = useSyncExternalStore(subscribe, hasGateSessionMarker, () => false);

  useEffect(() => {
    if (!profile || ready) return;
    setDisplayName(profile.displayName);
    setUsername(profile.username);
    setBio(profile.bio);
    setReady(true);
  }, [profile, ready]);

  useEffect(() => {
    try {
      setTheme(localStorage.getItem("cove-theme") === "light" ? "light" : "dark");
    } catch {
      setTheme("dark");
    }
  }, []);

  const save = useMutation({
    mutationFn: () =>
      saveProfile({
        data: {
          displayName,
          username,
          bio,
          avatarAction: avatar.action,
          avatarUrl: avatar.url,
          coverAction: cover.action,
          coverUrl: cover.url,
        },
      }),
    onSuccess: (next) => {
      client.setQueryData(["me"], next);
      setAvatar({ action: "keep", url: null });
      setCover({ action: "keep", url: null });
      void client.invalidateQueries({ queryKey: ["avatar"] });
    },
  });
  const privacy = useMutation({
    mutationFn: (next: { messagePolicy: MessagePolicy; showOnline: OnlinePolicy; searchable: boolean }) =>
      savePrivacy({ data: next }),
    onSuccess: (next) => client.setQueryData(["me"], next),
  });
  const unblock = useMutation({
    mutationFn: (userId: string) => unblockPerson({ data: userId }),
    onSuccess: () => void client.invalidateQueries({ queryKey: ["blocked"] }),
  });

  if (!profile) return <p className="px-5 py-8 text-sm text-muted">Loading settings…</p>;

  const avatarPreview =
    avatar.action === "clear" ? null : avatar.action === "set" ? avatar.url : profile.avatarUrl;
  const coverPreview =
    cover.action === "clear" ? null : cover.action === "set" ? cover.url : profile.coverUrl;

  async function pick(file: File | undefined, kind: "avatar" | "cover") {
    if (!file) return;
    try {
      const data = await compressImage(file, kind === "avatar" ? 512 : 1280, kind === "avatar" ? 0.72 : 0.66);
      const limit = kind === "avatar" ? 140_000 : 220_000;
      if (data.length > limit) throw new Error("That image is still too large.");
      setFileError(null);
      if (kind === "avatar") setAvatar({ action: "set", url: data });
      else setCover({ action: "set", url: data });
    } catch (cause) {
      setFileError(errorText(cause));
    }
  }

  function applyTheme(next: "dark" | "light") {
    setTheme(next);
    document.documentElement.classList.toggle("light", next === "light");
    try {
      localStorage.setItem("cove-theme", next);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="pb-8">
      <PageHeader kicker="You" title="Settings" />
      <div className="px-5">
        <div className={`cover-hue-${profile.hue % 6} relative h-32 overflow-hidden rounded-3xl`}>
          {coverPreview && <img src={coverPreview} alt="" className="h-full w-full object-cover" />}
        </div>
        <div className="-mt-8 px-2">
          <Avatar
            userId={profile.userId}
            name={displayName || profile.displayName}
            hue={profile.hue}
            url={avatarPreview}
            rev={avatar.action === "keep" ? profile.avatarRev : 0}
            size="lg"
          />
        </div>
        <div className="mt-4 flex gap-2">
          <label className="flex h-10 flex-1 cursor-pointer items-center justify-center rounded-2xl bg-elevated text-sm font-semibold">
            Profile photo
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(event) => {
                void pick(event.target.files?.[0], "avatar");
                event.target.value = "";
              }}
            />
          </label>
          <label className="flex h-10 flex-1 cursor-pointer items-center justify-center rounded-2xl bg-elevated text-sm font-semibold">
            Cover
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(event) => {
                void pick(event.target.files?.[0], "cover");
                event.target.value = "";
              }}
            />
          </label>
        </div>
        {fileError && <p className="mt-3 text-sm text-primary">{fileError}</p>}
        {(avatar.action !== "keep" || cover.action !== "keep" || profile.avatarUrl || profile.coverUrl) && (
          <button
            type="button"
            onClick={() => {
              setAvatar({ action: "clear", url: null });
              setCover({ action: "clear", url: null });
            }}
            className="mt-2 text-sm text-muted"
          >
            Remove photo and cover
          </button>
        )}

        <form
          className="mt-6 space-y-4"
          onSubmit={(event) => {
            event.preventDefault();
            save.mutate();
          }}
        >
          <Field label="Display name">
            <input
              value={displayName}
              maxLength={40}
              onChange={(event) => setDisplayName(event.target.value)}
              className="h-12 w-full rounded-2xl border border-line bg-surface px-4 outline-none"
            />
          </Field>
          <Field label="Username">
            <div className="flex h-12 items-center rounded-2xl border border-line bg-surface px-4">
              <span className="text-muted">@</span>
              <input
                value={username}
                maxLength={20}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                onChange={(event) => setUsername(event.target.value.toLowerCase())}
                className="h-full w-full bg-transparent px-1 outline-none"
              />
            </div>
          </Field>
          <Field label="Biography">
            <textarea
              value={bio}
              maxLength={160}
              rows={3}
              onChange={(event) => setBio(event.target.value)}
              className="w-full resize-none rounded-2xl border border-line bg-surface px-4 py-3 outline-none"
            />
            <span className="mt-1 block text-right text-xs text-muted tabular-nums">{bio.length}/160</span>
          </Field>
          {save.isError && <p className="text-sm text-primary">{errorText(save.error)}</p>}
          {save.isSuccess && <p className="text-sm text-primary">Profile saved.</p>}
          <button
            type="submit"
            disabled={save.isPending}
            className="h-12 w-full rounded-2xl bg-primary text-sm font-semibold text-primary-fg active:scale-[0.96] disabled:opacity-60"
          >
            {save.isPending ? "Saving…" : "Save profile"}
          </button>
        </form>

        <Section title="Privacy">
          <Choice
            label="Who can message you"
            value={profile.messagePolicy}
            options={[
              ["everyone", "Everyone"],
              ["friends", "Friends"],
            ]}
            onChange={(messagePolicy) =>
              privacy.mutate({
                messagePolicy: messagePolicy as MessagePolicy,
                showOnline: profile.showOnline,
                searchable: profile.searchable,
              })
            }
          />
          <Choice
            label="Who can see you're online"
            value={profile.showOnline}
            options={[
              ["everyone", "Everyone"],
              ["friends", "Friends"],
              ["nobody", "Nobody"],
            ]}
            onChange={(showOnline) =>
              privacy.mutate({
                messagePolicy: profile.messagePolicy,
                showOnline: showOnline as OnlinePolicy,
                searchable: profile.searchable,
              })
            }
          />
          <button
            type="button"
            onClick={() =>
              privacy.mutate({
                messagePolicy: profile.messagePolicy,
                showOnline: profile.showOnline,
                searchable: !profile.searchable,
              })
            }
            className="flex w-full items-center justify-between py-3 text-left"
          >
            <span>
              <span className="block text-sm font-medium">Appear in search</span>
              <span className="text-xs text-muted">{profile.searchable ? "People can find you" : "Hidden from search"}</span>
            </span>
            <span className={profile.searchable ? "h-7 w-12 rounded-full bg-primary p-1" : "h-7 w-12 rounded-full bg-elevated p-1"}>
              <span className={profile.searchable ? "block size-5 translate-x-5 rounded-full bg-primary-fg transition-transform" : "block size-5 rounded-full bg-fg transition-transform"} />
            </span>
          </button>
          {privacy.isError && <p className="text-sm text-primary">{errorText(privacy.error)}</p>}
        </Section>

        <Section title="Blocked">
          {blocked.data && blocked.data.length === 0 && (
            <p className="text-sm text-muted">You haven't blocked anyone.</p>
          )}
          <ul>
            {blocked.data?.map((person) => (
              <li key={person.userId} className="flex items-center justify-between gap-3 py-2">
                <span className="min-w-0">
                  <span className="block truncate font-medium">{person.displayName}</span>
                  <span className="block truncate text-sm text-muted">@{person.username}</span>
                </span>
                <button
                  type="button"
                  onClick={() => unblock.mutate(person.userId)}
                  className="h-10 rounded-2xl border border-line px-3 text-sm font-semibold"
                >
                  Unblock
                </button>
              </li>
            ))}
          </ul>
        </Section>

        <Section title="Appearance">
          <div className="grid grid-cols-2 gap-2">
            {(["dark", "light"] as const).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => applyTheme(option)}
                className={
                  theme === option
                    ? "h-11 rounded-2xl bg-primary text-sm font-semibold text-primary-fg"
                    : "h-11 rounded-2xl border border-line text-sm font-semibold"
                }
              >
                {option === "dark" ? "Dark" : "Light"}
              </button>
            ))}
          </div>
        </Section>

        <Section title="Account">
          <p className="text-sm">
            <span className="text-muted">Gmail</span>
            <span className="mt-1 block font-medium">{profile.email ?? "Signed in with Google"}</span>
          </p>
          <p className="mt-3 text-sm text-pretty text-muted">
            You sign in with Gmail. Password and recovery stay with Google, so Cove doesn't keep a separate password to change.
          </p>
          <div className="mt-4">
            <p className="text-xs text-muted">User ID</p>
            <p className="mt-1 truncate font-mono text-sm">{profile.userId}</p>
            <button
              type="button"
              onClick={() => {
                void navigator.clipboard?.writeText(profile.userId).then(() => {
                  setCopied(true);
                  setTimeout(() => setCopied(false), 1500);
                });
              }}
              className="mt-2 text-sm font-semibold text-primary"
            >
              {copied ? "Copied" : "Copy user ID"}
            </button>
          </div>
          {!gateSession && (
            <button
              type="button"
              disabled={signingOut}
              onClick={() => {
                setSigningOut(true);
                void signOut().catch(() => setSigningOut(false));
              }}
              className="mt-6 h-12 w-full rounded-2xl border border-line text-sm font-semibold active:scale-[0.96] disabled:opacity-60"
            >
              {signingOut ? "Signing out…" : "Log out"}
            </button>
          )}
        </Section>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-medium">{label}</span>
      {children}
    </label>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-8 border-t border-line pt-5">
      <h2 className="text-xs font-semibold tracking-widest text-muted uppercase">{title}</h2>
      <div className="mt-3">{children}</div>
    </section>
  );
}

function Choice({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: [string, string][];
  onChange: (value: string) => void;
}) {
  return (
    <div className="py-2">
      <p className="text-sm font-medium">{label}</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {options.map(([id, text]) => (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            className={
              value === id
                ? "h-10 rounded-2xl bg-primary px-3 text-sm font-semibold text-primary-fg"
                : "h-10 rounded-2xl border border-line px-3 text-sm font-semibold"
            }
          >
            {text}
          </button>
        ))}
      </div>
    </div>
  );
}
