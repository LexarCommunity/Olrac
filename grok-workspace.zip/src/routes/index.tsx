import { Link, createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { listConversations } from "@/lib/chat.functions";
import { formatWhen } from "@/lib/format";
import { Avatar } from "@/components/avatar";
import { Empty, PageHeader, RequireUser } from "@/components/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <RequireUser>
      <ChatList />
    </RequireUser>
  );
}

function ChatList() {
  const chats = useQuery({
    queryKey: ["conversations"],
    queryFn: () => listConversations(),
    refetchInterval: 2000,
  });
  return (
    <div>
      <PageHeader kicker="Cove" title="Chats" />
      {chats.isPending && <p className="px-5 py-8 text-sm text-muted">Loading conversations…</p>}
      {chats.isError && <p className="px-5 py-8 text-sm text-muted">Couldn't load chats. They'll retry.</p>}
      {chats.data && chats.data.length === 0 && (
        <Empty
          title="No chats yet"
          body="When you message someone, the thread shows up here with the latest line."
          action={
            <Link
              to="/search"
              className="inline-flex h-11 items-center rounded-2xl bg-primary px-5 text-sm font-semibold text-primary-fg"
            >
              Find people
            </Link>
          }
        />
      )}
      <ul>
        {chats.data?.map((chat) => (
          <li key={chat.id}>
            <Link
              to="/c/$conversationId"
              params={{ conversationId: String(chat.id) }}
              className="flex items-center gap-3 px-5 py-3 transition-colors hover:bg-surface"
            >
              <Avatar
                userId={chat.partner.userId}
                name={chat.partner.displayName}
                hue={chat.partner.hue}
                url={chat.partner.avatarUrl}
                rev={chat.partner.avatarRev}
                online={chat.partner.online}
              />
              <span className="min-w-0 flex-1">
                <span className="flex items-baseline justify-between gap-3">
                  <span className="truncate font-semibold">{chat.partner.displayName}</span>
                  <span className="shrink-0 text-xs text-muted tabular-nums">{formatWhen(chat.lastAt)}</span>
                </span>
                <span className="mt-0.5 flex items-center justify-between gap-3">
                  <span className="truncate text-sm text-muted">
                    {chat.typing ? "Typing…" : `${chat.mine && chat.preview !== "No messages yet" ? "You: " : ""}${chat.preview}`}
                  </span>
                  {chat.unread > 0 && (
                    <span className="grid min-w-5 place-items-center rounded-full bg-primary px-1.5 text-xs font-semibold text-primary-fg tabular-nums">
                      {chat.unread}
                    </span>
                  )}
                </span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
