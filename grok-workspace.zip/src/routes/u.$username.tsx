import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import {
  blockPerson,
  getProfile,
  openConversation,
  requestFriend,
  respondFriend,
  unblockPerson,
} from "@/lib/chat.functions";
import { errorText, formatJoined } from "@/lib/format";
import { Avatar } from "@/components/avatar";
import { RequireUser } from "@/components/shell";

export const Route = createFileRoute("/u/$username")({ component: ProfilePage });

function ProfilePage() {
  const { username } = Route.useParams();
  return (
    <RequireUser immersive>
      <Profile username={username} />
    </RequireUser>
  );
}

function Profile({ username }: { username: string }) {
  const navigate = useNavigate();
  const client = useQueryClient();
  const profile = useQuery({
    queryKey: ["profile", username],
    queryFn: () => getProfile({ data: username }),
  });
  const refresh = () => {
    void client.invalidateQueries({ queryKey: ["profile", username] });
    void client.invalidateQueries({ queryKey: ["people"] });
    void client.invalidateQueries({ queryKey: ["notifications"] });
    void client.invalidateQueries({ queryKey: ["blocked"] });
  };
  const add = useMutation({
    mutationFn: () => requestFriend({ data: profile.data?.userId ?? "" }),
    onSuccess: refresh,
  });
  const respond = useMutation({
    mutationFn: (accept: boolean) =>
      respondFriend({ data: { friendshipId: profile.data?.friendshipId ?? 0, accept } }),
    onSuccess: refresh,
  });
  const open = useMutation({
    mutationFn: () => openConversation({ data: profile.data?.userId ?? "" }),
    onSuccess: (result) => {
      void navigate({ to: "/c/$conversationId", params: { conversationId: String(result.conversationId) } });
    },
  });
  const block = useMutation({
    mutationFn: () =>
      profile.data?.blockedByMe
        ? unblockPerson({ data: profile.data.userId })
        : blockPerson({ data: profile.data?.userId ?? "" }),
    onSuccess: refresh,
  });

  const person = profile.data;
  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="sticky top-0 z-10 flex items-center gap-2 bg-bg/90 px-3 py-3 backdrop-blur">
        <Link to="/search" aria-label="Back" className="grid size-11 place-items-center rounded-full">
          <ArrowLeft className="size-5" />
        </Link>
        <span className="font-semibold">Profile</span>
      </div>
      {profile.isPending && <p className="px-5 py-8 text-sm text-muted">Loading profile…</p>}
      {profile.data === null && (
        <p className="px-5 py-16 text-center text-sm text-muted">That profile isn't available.</p>
      )}
      {person && (
        <div>
          <div className={`cover-hue-${person.hue % 6} relative h-36`}>
            {person.coverUrl && (
              <img src={person.coverUrl} alt="" className="h-full w-full object-cover" />
            )}
          </div>
          <div className="px-5 pb-10">
            <div className="-mt-10">
              <Avatar
                userId={person.userId}
                name={person.displayName}
                hue={person.hue}
                url={person.avatarUrl}
                rev={person.avatarRev}
                online={person.self ? null : person.online}
                size="xl"
              />
            </div>
            <h1 className="mt-3 text-2xl font-semibold tracking-tight">{person.displayName}</h1>
            <p className="text-muted">@{person.username}</p>
            {person.online === true && <p className="mt-2 text-sm font-medium text-online">Online</p>}
            {person.online === false && <p className="mt-2 text-sm text-muted">Offline</p>}
            {person.bio && <p className="mt-4 text-pretty">{person.bio}</p>}
            <p className="mt-3 text-sm text-muted">Joined {formatJoined(person.createdAt)}</p>
            {!person.self && (
              <div className="mt-6 flex gap-2">
                {person.relation === "incoming" ? (
                  <>
                    <button
                      type="button"
                      disabled={respond.isPending}
                      onClick={() => respond.mutate(true)}
                      className="h-12 flex-1 rounded-2xl bg-primary text-sm font-semibold text-primary-fg active:scale-[0.96]"
                    >
                      Accept
                    </button>
                    <button
                      type="button"
                      disabled={respond.isPending}
                      onClick={() => respond.mutate(false)}
                      className="h-12 flex-1 rounded-2xl border border-line text-sm font-semibold active:scale-[0.96]"
                    >
                      Decline
                    </button>
                  </>
                ) : (
                  <button
                    type="button"
                    disabled={add.isPending || person.relation === "outgoing" || person.relation === "friends"}
                    onClick={() => add.mutate()}
                    className="h-12 flex-1 rounded-2xl bg-primary text-sm font-semibold text-primary-fg active:scale-[0.96] disabled:opacity-60"
                  >
                    {person.relation === "friends"
                      ? "Friends"
                      : person.relation === "outgoing"
                        ? "Requested"
                        : "Add friend"}
                  </button>
                )}
                <button
                  type="button"
                  disabled={open.isPending || !person.canSend}
                  onClick={() => open.mutate()}
                  className="h-12 flex-1 rounded-2xl border border-line text-sm font-semibold active:scale-[0.96] disabled:opacity-50"
                >
                  Message
                </button>
              </div>
            )}
            {person.self && (
              <Link
                to="/settings"
                className="mt-6 flex h-12 items-center justify-center rounded-2xl bg-primary text-sm font-semibold text-primary-fg"
              >
                Edit profile
              </Link>
            )}
            {person.sendHint && !person.self && (
              <p className="mt-3 text-sm text-muted">{person.sendHint}</p>
            )}
            {(add.isError || open.isError || respond.isError || block.isError) && (
              <p className="mt-3 text-sm text-primary">
                {errorText(add.error ?? open.error ?? respond.error ?? block.error)}
              </p>
            )}
            {!person.self && (
              <button
                type="button"
                onClick={() => block.mutate()}
                className="mt-8 text-sm font-medium text-muted"
              >
                {person.blockedByMe ? "Unblock" : "Block"} @{person.username}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
