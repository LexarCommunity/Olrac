import { useQuery } from "@tanstack/react-query";
import { getAvatar } from "@/lib/chat.functions";
import { cn } from "@/lib/cn";

const sizes = {
  sm: "size-10 text-sm",
  md: "size-12 text-base",
  lg: "size-16 text-xl",
  xl: "size-24 text-3xl",
} as const;

export function Avatar({
  userId,
  name,
  hue,
  url,
  rev,
  online,
  size = "md",
}: {
  userId: string;
  name: string;
  hue: number;
  url?: string | null;
  rev: number;
  online?: boolean | null;
  size?: keyof typeof sizes;
}) {
  const needsFetch = !url && rev > 0;
  const photo = useQuery({
    queryKey: ["avatar", userId, rev],
    queryFn: () => getAvatar({ data: userId }),
    enabled: needsFetch,
    staleTime: Infinity,
  });
  const src = url || photo.data || null;
  const initial = (name.trim()[0] ?? "?").toUpperCase();
  return (
    <span className="relative inline-flex shrink-0">
      {src ? (
        <img
          src={src}
          alt=""
          className={cn("rounded-full object-cover", sizes[size])}
        />
      ) : (
        <span
          className={cn(
            "grid place-items-center rounded-full font-semibold text-primary-fg",
            `avatar-hue-${hue % 6}`,
            sizes[size],
          )}
        >
          {initial}
        </span>
      )}
      {online === true && (
        <span className="absolute right-0 bottom-0 size-3 rounded-full bg-online ring-2 ring-bg" />
      )}
      {online === false && (
        <span className="absolute right-0 bottom-0 size-3 rounded-full bg-elevated ring-2 ring-line" />
      )}
    </span>
  );
}
