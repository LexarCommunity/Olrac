import { cn } from "@/lib/cn";

export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-9", className)} aria-hidden>
      <rect width="32" height="32" rx="10" className="fill-primary" />
      <path
        d="M8 21.2c2.1-5 4.8-7.7 8-7.7s5.9 2.7 8 7.7"
        fill="none"
        stroke="var(--color-primary-fg)"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <circle cx="16" cy="11.2" r="1.7" fill="var(--color-primary-fg)" />
    </svg>
  );
}
