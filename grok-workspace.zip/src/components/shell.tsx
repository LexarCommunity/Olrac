import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, MessageSquare, Search, Settings } from "lucide-react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { ensureProfile, heartbeat, listConversations, listNotifications, saveProfile } from "@/lib/chat.functions";
import { cn } from "@/lib/cn";
import { errorText } from "@/lib/format";
import { Mark } from "@/components/mark";

export function Stage({ children }: { children: ReactNode }) {
  return (
    <div className="bg-stage md:grid md:h-dvh md:grid-cols-2 md:overflow-hidden">
      <aside className="hidden h-dvh flex-col justify-between px-14 py-16 md:flex">
        <div className="flex items-center gap-3">
          <Mark />
          <span className="text-lg font-semibold tracking-tight">Cove</span>
        </div>
        <div className="max-w-md">
          <h1 className="text-4xl font-semibold tracking-tight text-balance">
            Talk with the people you choose.
          </h1>
          <p className="mt-4 text-lg text-pretty text-muted">
            Search for someone, send a note, and keep the thread between the two of you.
          </p>
        </div>
        <p className="text-sm text-muted">Sign in with Gmail. Your username is yours to pick.</p>
      </aside>
      <div className="flex h-dvh min-h-dvh flex-col bg-bg md:min-h-0 md:border-l md:border-line">{children}</div>
    </div>
  );
}

export function Splash() {
  return (
    <div className="grid flex-1 place-items-center gap-3">
      <Mark />
      <p className="text-sm font-medium text-muted">Opening Cove…</p>
    </div>
  );
}

function Setup({
  displayName,
  username,
}: {
  displayName: string;
  username: string;
}) {
  const client = useQueryClient();
  const [name, setName] = useState(displayName);
  const [handle, setHandle] = useState(username);
  const save = useMutation({
    mutationFn: () =>
      saveProfile({
        data: {
          displayName: name,
          username: handle,
          bio: "",
          avatarAction: "keep",
          coverAction: "keep",
        },
      }),
    onSuccess: (me) => {
      client.setQueryData(["me"], me);
    },
  });
  return (
    <div className="flex flex-1 flex-col justify-between px-6 py-10">
      <div>
        <p className="text-xs font-semibold tracking-widest text-primary uppercase">Your name on Cove</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-balance">
          Pick a username people can find.
        </h1>
        <p className="mt-3 text-pretty text-muted">
          You can change this later. Display name is what shows in chats.
        </p>
      </div>
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          save.mutate();
        }}
      >
        <label className="block space-y-2">
          <span className="text-sm font-medium">Display name</span>
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            maxLength={40}
            required
            className="h-12 w-full rounded-2xl border border-line bg-surface px-4 text-fg outline-none"
          />
        </label>
        <label className="block space-y-2">
          <span className="text-sm font-medium">Username</span>
          <div className="flex h-12 items-center rounded-2xl border border-line bg-surface px-4">
            <span className="text-muted">@</span>
            <input
              value={handle}
              onChange={(event) => setHandle(event.target.value.toLowerCase())}
              maxLength={20}
              required
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              className="h-full w-full bg-transparent px-1 text-fg outline-none"
            />
          </div>
        </label>
        {save.isError && <p className="text-sm text-primary">{errorText(save.error)}</p>}
        <button
          type="submit"
          disabled={save.isPending}
          className="h-12 w-full rounded-2xl bg-primary text-sm font-semibold text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-60"
        >
          {save.isPending ? "Saving…" : "Continue"}
        </button>
      </form>
    </div>
  );
}

export function RequireUser({
  children,
  immersive = false,
}: {
  children: ReactNode;
  immersive?: boolean;
}) {
  const { user, isPending } = useCurrentUserState();
  const me = useQuery({
    queryKey: ["me"],
    queryFn: () => ensureProfile(),
    enabled: Boolean(user),
    staleTime: 15_000,
  });
  useEffect(() => {
    if (!user) return;
    let stop = false;
    const beat = () => {
      if (!stop) void heartbeat().catch(() => undefined);
    };
    beat();
    const timer = setInterval(beat, 15_000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [user]);

  if (isPending || (user && me.isPending)) {
    return (
      <Stage>
        <Splash />
      </Stage>
    );
  }
  if (!user) return <RedirectToSignIn />;
  if (me.isError) {
    const text = errorText(me.error);
    if (/unauthorized/i.test(text)) return <RedirectToSignIn />;
    return (
      <Stage>
        <div className="grid flex-1 place-items-center px-6 text-center">
          <div>
            <p className="text-lg font-semibold">Cove couldn't open your profile.</p>
            <p className="mt-2 text-sm text-muted">{text}</p>
            <button
              type="button"
              onClick={() => void me.refetch()}
              className="mt-5 h-11 rounded-2xl bg-primary px-5 text-sm font-semibold text-primary-fg"
            >
              Try again
            </button>
          </div>
        </div>
      </Stage>
    );
  }
  if (me.data && !me.data.setupDone) {
    return (
      <Stage>
        <Setup displayName={me.data.displayName} username={me.data.username} />
      </Stage>
    );
  }
  return (
    <Stage>
      <div className="flex min-h-0 flex-1 flex-col">
        {immersive ? (
          <div className="flex min-h-0 flex-1 flex-col">{children}</div>
        ) : (
          <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>
        )}
        {!immersive && <BottomNav />}
      </div>
    </Stage>
  );
}

function BottomNav() {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const chats = useQuery({
    queryKey: ["conversations"],
    queryFn: () => listConversations(),
    refetchInterval: 2000,
  });
  const notes = useQuery({
    queryKey: ["notifications"],
    queryFn: () => listNotifications(),
    refetchInterval: 2000,
  });
  const unreadChats = (chats.data ?? []).reduce((sum, chat) => sum + chat.unread, 0);
  const unreadNotes = notes.data?.unread ?? 0;
  const items = [
    { to: "/", label: "Chat", icon: MessageSquare, badge: unreadChats, exact: true },
    { to: "/search", label: "Search", icon: Search, badge: 0, exact: false },
    { to: "/notifications", label: "Notification", icon: Bell, badge: unreadNotes, exact: false },
    { to: "/settings", label: "Settings", icon: Settings, badge: 0, exact: false },
  ] as const;
  return (
    <nav className="pb-safe border-t border-line bg-bg">
      <ul className="grid grid-cols-4">
        {items.map((item) => {
          const active = item.exact ? path === item.to : path.startsWith(item.to);
          const Icon = item.icon;
          return (
            <li key={item.to}>
              <Link
                to={item.to}
                className={cn(
                  "flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium",
                  active ? "text-primary" : "text-muted",
                )}
              >
                <span className="relative">
                  <Icon className="size-5" strokeWidth={active ? 2.25 : 1.75} />
                  {item.badge > 0 && (
                    <span className="absolute -top-1 -right-2 grid min-w-4 place-items-center rounded-full bg-primary px-1 text-xs leading-none font-semibold text-primary-fg">
                      {item.badge > 9 ? "9+" : item.badge}
                    </span>
                  )}
                </span>
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function PageHeader({
  kicker,
  title,
  action,
}: {
  kicker?: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <header className="flex items-end justify-between gap-3 px-5 pt-6 pb-3">
      <div>
        {kicker && (
          <p className="text-xs font-semibold tracking-widest text-primary uppercase">{kicker}</p>
        )}
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
      </div>
      {action}
    </header>
  );
}

export function Empty({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="px-5 py-16 text-center">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="mx-auto mt-2 max-w-xs text-pretty text-sm text-muted">{body}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
