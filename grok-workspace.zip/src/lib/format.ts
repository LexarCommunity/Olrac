import { format, isToday, isYesterday } from "date-fns";

export function errorText(error: unknown): string {
  if (error instanceof Error && error.message) {
    const message = error.message.replace(/^Error:\s*/, "");
    if (message && message !== "Failed to fetch") return message;
  }
  return "Something went wrong. Try again.";
}

export function formatWhen(iso: string | null): string {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  if (isToday(date)) return format(date, "h:mm a");
  if (isYesterday(date)) return "Yesterday";
  return format(date, "MMM d");
}

export function formatDay(iso: string): string {
  const date = new Date(iso);
  if (isToday(date)) return "Today";
  if (isYesterday(date)) return "Yesterday";
  return format(date, "MMMM d");
}

export function formatJoined(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return format(date, "MMMM yyyy");
}

export function dayKey(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return format(date, "yyyy-MM-dd");
}
