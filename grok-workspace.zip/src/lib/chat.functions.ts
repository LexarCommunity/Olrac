import { createServerFn } from "@tanstack/react-start";
import { getSql, type Sql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";

export type Relation = "none" | "outgoing" | "incoming" | "friends";
export type MessagePolicy = "everyone" | "friends";
export type OnlinePolicy = "everyone" | "friends" | "nobody";

export type Person = {
  userId: string;
  username: string;
  displayName: string;
  bio: string;
  hue: number;
  avatarUrl: string | null;
  avatarRev: number;
  online: boolean | null;
  relation: Relation;
};

export type Me = {
  userId: string;
  username: string;
  displayName: string;
  bio: string;
  email: string | null;
  hue: number;
  avatarUrl: string | null;
  avatarRev: number;
  coverUrl: string | null;
  coverRev: number;
  setupDone: boolean;
  messagePolicy: MessagePolicy;
  showOnline: OnlinePolicy;
  searchable: boolean;
  createdAt: string;
};

export type Conversation = {
  id: number;
  partner: Person;
  preview: string;
  lastAt: string | null;
  unread: number;
  typing: boolean;
  mine: boolean;
};

export type ChatMessage = {
  id: number;
  senderId: string;
  body: string;
  hasImage: boolean;
  createdAt: string;
  deliveredAt: string | null;
};

export type Thread = {
  conversationId: number;
  partner: Person;
  messages: ChatMessage[];
  partnerReadAt: string | null;
  typing: boolean;
  canSend: boolean;
  sendHint: string | null;
  blockedByMe: boolean;
};

export type Notice = {
  id: number;
  kind: "friend_request" | "friend_accepted" | "message";
  read: boolean;
  createdAt: string;
  actor: Person;
  friendshipId: number | null;
  friendshipStatus: "pending" | "accepted" | "declined" | null;
  conversationId: number | null;
};

type Row = Record<string, unknown>;

const USERNAME = /^[a-z][a-z0-9._]{2,19}$/;
const ONLINE_MS = 50_000;

const HELLO: Record<string, string> = {
  guide_mara: "You found me. I'm Mara — send a song, a sentence, or a complaint about the weather.",
  guide_jun: "Jun here. If you could take a train anywhere this week, where does it stop?",
  guide_nia: "Hey, I'm Nia. I saw you on Cove. What are you growing, or are you just getting started?",
  guide_cass: "Cass. I'm up. Tell me something that doesn't belong in a group chat.",
  guide_theo: "Theo. I just burned the garlic. Distract me — what did you eat today?",
  guide_sable: "Sable. I'm avoiding my draft. Give me one true sentence and I'll trade you one.",
};

const REPLIES: Record<string, string[]> = {
  guide_mara: [
    "That one stays with me. What are you listening to lately?",
    "Say more. I have time.",
    "If that message were a song, which one is it?",
    "I like the way you put that.",
  ],
  guide_jun: [
    "I just sketched that in the margin. Keep going.",
    "Which way would you walk it — slow, or trying to make the train?",
    "Noted. I want the detail you almost left out.",
    "That sounds like a place worth getting lost in.",
  ],
  guide_nia: [
    "Tell me if it needs more light or more quiet.",
    "I know that feeling. Water it anyway.",
    "Ha. My pothos would have opinions about this.",
    "Come back tomorrow and tell me if it changed.",
  ],
  guide_cass: [
    "Okay. I'm still here.",
    "That's the honest version. I prefer it.",
    "Read that again like you meant it. You did.",
    "Night shift agrees with you.",
  ],
  guide_theo: [
    "Salt it earlier next time. And then tell me how it went.",
    "I'd eat that. Happily, and too fast.",
    "Recipe is a rumor. Taste is the editor.",
    "Come over. I'm making too much on purpose.",
  ],
  guide_sable: [
    "That's a line I'd steal if I were a worse friend.",
    "Don't tidy it. Send the messy cut.",
    "I wrote that down. Don't tell my notebook.",
    "One more sentence. Then I'll let you go.",
  ],
};

function str(row: Row, key: string): string {
  const value = row[key];
  if (value instanceof Date) return value.toISOString();
  if (value == null) return "";
  return String(value);
}

function strOrNull(row: Row, key: string): string | null {
  const value = row[key];
  if (value == null) return null;
  if (value instanceof Date) return value.toISOString();
  const text = String(value);
  return text.length ? text : null;
}

function num(row: Row, key: string): number {
  const value = Number(row[key] ?? 0);
  return Number.isFinite(value) ? value : 0;
}

function bool(row: Row, key: string): boolean {
  const value = row[key];
  return value === true || value === "t" || value === "true" || value === 1;
}

function fail(message: string): never {
  throw new Error(message);
}

function pair(a: string, b: string): [string, string] {
  return a < b ? [a, b] : [b, a];
}

function hueOf(id: string): number {
  let hash = 0;
  for (const char of id) hash = (hash + char.charCodeAt(0) * 7) % 6;
  return hash;
}

function suggestUsername(name: string, email: string | null, id: string): string {
  const fromEmail = email?.split("@")[0] ?? "";
  const raw = (fromEmail || name || "cove").toLowerCase().replace(/[^a-z0-9._]/g, "");
  const trimmed = raw.replace(/^[._]+|[._]+$/g, "").slice(0, 14);
  const stem = trimmed.length >= 3 && /^[a-z]/.test(trimmed) ? trimmed : "cove";
  const suffix = id.replace(/[^a-z0-9]/gi, "").slice(-4).toLowerCase();
  const candidate = `${stem}${suffix ? `.${suffix}` : ""}`.slice(0, 20);
  return USERNAME.test(candidate) ? candidate : `cove.${suffix || "me"}`.slice(0, 20);
}

function cleanImage(input: string | null | undefined, max: number): string | null {
  if (input == null || input === "") return null;
  if (!input.startsWith("data:image/")) fail("Use a JPEG or PNG.");
  if (input.length > max) fail("That image is too large. Try a smaller one.");
  return input;
}

function onlineOf(show: string, lastSeen: string, friends: boolean): boolean | null {
  if (show === "nobody") return null;
  if (show === "friends" && !friends) return null;
  const then = new Date(lastSeen).getTime();
  if (!Number.isFinite(then)) return false;
  return Date.now() - then < ONLINE_MS;
}

type Social = {
  relation: Map<string, { status: string; requester: string; addressee: string; id: number }>;
  blocked: Set<string>;
  blockedMe: Set<string>;
};

async function loadSocial(sql: Sql, me: string): Promise<Social> {
  const [friends, blocks] = await Promise.all([
    sql<Row>`select id, requester_id, addressee_id, status from friendships
      where requester_id = ${me} or addressee_id = ${me}`,
    sql<Row>`select user_id, blocked_id from blocks
      where user_id = ${me} or blocked_id = ${me}`,
  ]);
  const relation = new Map<string, { status: string; requester: string; addressee: string; id: number }>();
  for (const row of friends) {
    const requester = str(row, "requester_id");
    const addressee = str(row, "addressee_id");
    const other = requester === me ? addressee : requester;
    relation.set(other, {
      status: str(row, "status"),
      requester,
      addressee,
      id: num(row, "id"),
    });
  }
  const blocked = new Set<string>();
  const blockedMe = new Set<string>();
  for (const row of blocks) {
    if (str(row, "user_id") === me) blocked.add(str(row, "blocked_id"));
    else blockedMe.add(str(row, "user_id"));
  }
  return { relation, blocked, blockedMe };
}

function relationOf(social: Social, other: string): Relation {
  const row = social.relation.get(other);
  if (!row || row.status === "declined") return "none";
  if (row.status === "accepted") return "friends";
  return row.requester === other ? "incoming" : "outgoing";
}

function toPerson(row: Row, social: Social, me: string): Person {
  const userId = str(row, "user_id");
  const relation = userId === me ? "friends" : relationOf(social, userId);
  const friends = relation === "friends";
  const avatar = strOrNull(row, "avatar_url");
  return {
    userId,
    username: str(row, "username"),
    displayName: str(row, "display_name"),
    bio: str(row, "bio"),
    hue: num(row, "hue"),
    avatarUrl: avatar?.startsWith("https://") ? avatar : null,
    avatarRev: num(row, "avatar_rev"),
    online: onlineOf(str(row, "show_online"), str(row, "last_seen"), friends),
    relation: userId === me ? "none" : relation,
  };
}

async function requireProfile(sql: Sql, userId: string): Promise<Row> {
  const rows = await sql<Row>`select * from profiles where user_id = ${userId}`;
  if (!rows[0]) fail("Set up your profile first.");
  return rows[0];
}

function mapMe(row: Row, email: string | null): Me {
  return {
    userId: str(row, "user_id"),
    username: str(row, "username"),
    displayName: str(row, "display_name"),
    bio: str(row, "bio"),
    email,
    hue: num(row, "hue"),
    avatarUrl: strOrNull(row, "avatar_url"),
    avatarRev: num(row, "avatar_rev"),
    coverUrl: strOrNull(row, "cover_url"),
    coverRev: num(row, "cover_rev"),
    setupDone: bool(row, "setup_done"),
    messagePolicy: (str(row, "message_policy") === "friends" ? "friends" : "everyone") as MessagePolicy,
    showOnline: (["everyone", "friends", "nobody"].includes(str(row, "show_online"))
      ? str(row, "show_online")
      : "everyone") as OnlinePolicy,
    searchable: bool(row, "searchable"),
    createdAt: str(row, "created_at"),
  };
}

async function accountEmail(sql: Sql, userId: string): Promise<{ name: string; email: string | null; image: string | null }> {
  const rows = await sql<Row>`select "name" as name, "email" as email, "image" as image from "user" where "id" = ${userId}`;
  const row = rows[0];
  if (!row) return { name: "New member", email: null, image: null };
  return {
    name: str(row, "name") || "New member",
    email: strOrNull(row, "email"),
    image: strOrNull(row, "image"),
  };
}

async function notify(
  sql: Sql,
  userId: string,
  actorId: string,
  kind: Notice["kind"],
  extra: { friendshipId?: number; conversationId?: number },
) {
  if (userId.startsWith("guide_")) return;
  if (kind === "message" && extra.conversationId) {
    const updated = await sql<Row>`update notifications
      set created_at = now(), read = false, actor_id = ${actorId}
      where user_id = ${userId} and kind = 'message' and conversation_id = ${extra.conversationId} and read = false
      returning id`;
    if (updated.length) return;
  }
  await sql`insert into notifications (user_id, actor_id, kind, friendship_id, conversation_id)
    values (${userId}, ${actorId}, ${kind}, ${extra.friendshipId ?? null}, ${extra.conversationId ?? null})`;
}

async function ensureConversation(sql: Sql, me: string, other: string): Promise<number> {
  const [userA, userB] = pair(me, other);
  const inserted = await sql<Row>`insert into conversations (user_a, user_b, created_by)
    values (${userA}, ${userB}, ${me})
    on conflict (user_a, user_b) do nothing
    returning id`;
  if (inserted[0]) return num(inserted[0], "id");
  const found = await sql<Row>`select id from conversations where user_a = ${userA} and user_b = ${userB}`;
  return num(found[0], "id");
}

async function postGuideHello(sql: Sql, guideId: string, userId: string) {
  const conversationId = await ensureConversation(sql, userId, guideId);
  const existing = await sql<Row>`select id from messages where conversation_id = ${conversationId} limit 1`;
  if (existing.length) return;
  await sql`insert into messages (conversation_id, sender_id, body, delivered_at)
    values (${conversationId}, ${guideId}, ${HELLO[guideId] ?? "Hey."}, now())`;
  await notify(sql, userId, guideId, "message", { conversationId });
}

async function maybeGuideReply(sql: Sql, conversationId: number, me: string) {
  const rows = await sql<Row>`select p.user_id, p.is_guide,
      m.id as message_id, m.sender_id, m.created_at
    from conversations c
    join profiles p on p.user_id = case when c.user_a = ${me} then c.user_b else c.user_a end
    left join lateral (
      select id, sender_id, created_at from messages
      where conversation_id = c.id
      order by id desc
      limit 1
    ) m on true
    where c.id = ${conversationId} and (c.user_a = ${me} or c.user_b = ${me})`;
  const row = rows[0];
  if (!row || !bool(row, "is_guide") || !row.message_id) return;
  if (str(row, "sender_id") !== me) return;
  const guideId = str(row, "user_id");
  const age = Date.now() - new Date(str(row, "created_at")).getTime();
  await sql`update messages set delivered_at = coalesce(delivered_at, now())
    where conversation_id = ${conversationId} and sender_id = ${me} and delivered_at is null`;
  if (age < 1200) {
    await sql`insert into typing (conversation_id, user_id, updated_at)
      values (${conversationId}, ${guideId}, now())
      on conflict (conversation_id, user_id) do update set updated_at = now()`;
    return;
  }
  const lines = REPLIES[guideId] ?? ["I'm here."];
  const body = lines[num(row, "message_id") % lines.length] ?? lines[0];
  const inserted = await sql<Row>`insert into messages (conversation_id, sender_id, body)
    select ${conversationId}, ${guideId}, ${body}
    where exists (
      select 1 from messages
      where conversation_id = ${conversationId}
        and id = (select max(id) from messages where conversation_id = ${conversationId})
        and sender_id = ${me}
        and created_at <= now() - interval '1.2 seconds'
    )
    and not exists (
      select 1 from messages
      where conversation_id = ${conversationId}
        and sender_id = ${guideId}
        and id > (select max(id) from messages where conversation_id = ${conversationId} and sender_id = ${me})
    )
    returning id`;
  if (!inserted.length) return;
  await sql`delete from typing where conversation_id = ${conversationId} and user_id = ${guideId}`;
  await sql`insert into reads (conversation_id, user_id, last_read_at)
    values (${conversationId}, ${guideId}, now())
    on conflict (conversation_id, user_id) do update set last_read_at = now()`;
  await notify(sql, me, guideId, "message", { conversationId });
}

function canSendTo(policy: string, friends: boolean, blocked: boolean): { ok: boolean; hint: string | null } {
  if (blocked) return { ok: false, hint: "You can't message this person." };
  if (policy === "friends" && !friends) {
    return { ok: false, hint: "Only friends can message them. Send a request first." };
  }
  return { ok: true, hint: null };
}

export const ensureProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Me> => {
    const sql = await getSql();
    const me = context.userId;
    const existing = await sql<Row>`select * from profiles where user_id = ${me}`;
    const account = await accountEmail(sql, me);
    if (existing[0]) return mapMe(existing[0], account.email);

    const image = account.image?.startsWith("https://") ? account.image : null;
    let username = suggestUsername(account.name, account.email, me);
    for (let attempt = 0; attempt < 6; attempt += 1) {
      try {
        await sql`insert into profiles (
          user_id, username, display_name, hue, avatar_url, avatar_rev, setup_done
        ) values (
          ${me}, ${username}, ${account.name.slice(0, 40) || "New member"}, ${hueOf(me)},
          ${image}, ${image ? 1 : 0}, false
        )`;
        break;
      } catch (error) {
        const text = error instanceof Error ? error.message : String(error);
        if (!/unique|duplicate/i.test(text)) throw error;
        username = suggestUsername(account.name, account.email, `${me}${attempt + 2}`);
        if (attempt === 5) fail("Could not reserve a username. Try again.");
      }
    }
    const row = await requireProfile(sql, me);
    await sql`insert into friendships (requester_id, addressee_id, status)
      values ('guide_nia', ${me}, 'pending')
      on conflict do nothing`;
    const pending = await sql<Row>`select id from friendships
      where requester_id = 'guide_nia' and addressee_id = ${me} and status = 'pending'`;
    if (pending[0]) {
      await notify(sql, me, "guide_nia", "friend_request", { friendshipId: num(pending[0], "id") });
    }
    return mapMe(row, account.email);
  });

const profileInput = (input: {
  username: string;
  displayName: string;
  bio: string;
  avatarAction: "keep" | "set" | "clear";
  avatarUrl?: string | null;
  coverAction: "keep" | "set" | "clear";
  coverUrl?: string | null;
}) => {
  const username = input.username.trim().toLowerCase();
  const displayName = input.displayName.trim();
  const bio = input.bio.trim();
  if (!USERNAME.test(username)) {
    fail("Usernames are 3–20 characters and start with a letter. Use letters, numbers, dots, or underscores.");
  }
  if (displayName.length < 1 || displayName.length > 40) fail("Display name needs 1–40 characters.");
  if (bio.length > 160) fail("Bio stays under 160 characters.");
  return {
    username,
    displayName,
    bio,
    avatarAction: input.avatarAction,
    avatarUrl: input.avatarAction === "set" ? cleanImage(input.avatarUrl, 140_000) : null,
    coverAction: input.coverAction,
    coverUrl: input.coverAction === "set" ? cleanImage(input.coverUrl, 220_000) : null,
  };
};

export const saveProfile = createServerFn({ method: "POST" })
  .validator(profileInput)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Me> => {
    const sql = await getSql();
    const me = context.userId;
    await requireProfile(sql, me);
    const taken = await sql<Row>`select user_id from profiles
      where lower(username) = ${data.username} and user_id <> ${me}`;
    if (taken.length) fail("That username is taken.");
    if (data.avatarAction === "keep" && data.coverAction === "keep") {
      await sql`update profiles set
        username = ${data.username},
        display_name = ${data.displayName},
        bio = ${data.bio},
        setup_done = true
        where user_id = ${me}`;
    } else {
      await sql`update profiles set
        username = ${data.username},
        display_name = ${data.displayName},
        bio = ${data.bio},
        setup_done = true,
        avatar_url = case
          when ${data.avatarAction} = 'set' then ${data.avatarUrl}
          when ${data.avatarAction} = 'clear' then null
          else avatar_url end,
        avatar_rev = case when ${data.avatarAction} = 'keep' then avatar_rev else avatar_rev + 1 end,
        cover_url = case
          when ${data.coverAction} = 'set' then ${data.coverUrl}
          when ${data.coverAction} = 'clear' then null
          else cover_url end,
        cover_rev = case when ${data.coverAction} = 'keep' then cover_rev else cover_rev + 1 end
        where user_id = ${me}`;
    }
    const account = await accountEmail(sql, me);
    return mapMe(await requireProfile(sql, me), account.email);
  });

export const savePrivacy = createServerFn({ method: "POST" })
  .validator((input: { messagePolicy: MessagePolicy; showOnline: OnlinePolicy; searchable: boolean }) => {
    if (input.messagePolicy !== "everyone" && input.messagePolicy !== "friends") fail("Choose who can message you.");
    if (!["everyone", "friends", "nobody"].includes(input.showOnline)) fail("Choose who can see you're online.");
    return {
      messagePolicy: input.messagePolicy,
      showOnline: input.showOnline,
      searchable: Boolean(input.searchable),
    };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Me> => {
    const sql = await getSql();
    await sql`update profiles set
      message_policy = ${data.messagePolicy},
      show_online = ${data.showOnline},
      searchable = ${data.searchable}
      where user_id = ${context.userId}`;
    const account = await accountEmail(sql, context.userId);
    return mapMe(await requireProfile(sql, context.userId), account.email);
  });

export const heartbeat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`update profiles set last_seen = now() where user_id = ${context.userId}`;
    await sql`update profiles set last_seen = now()
      where user_id in ('guide_mara', 'guide_jun', 'guide_nia', 'guide_cass')`;
    return { ok: true };
  });

export const getAvatar = createServerFn({ method: "GET" })
  .validator((userId: string) => userId.slice(0, 80))
  .middleware([authMiddleware])
  .handler(async ({ context, data: userId }): Promise<string | null> => {
    const sql = await getSql();
    const social = await loadSocial(sql, context.userId);
    if (social.blocked.has(userId) || social.blockedMe.has(userId)) return null;
    const rows = await sql<Row>`select avatar_url from profiles where user_id = ${userId}`;
    return strOrNull(rows[0] ?? {}, "avatar_url");
  });

export const getMessageImage = createServerFn({ method: "GET" })
  .validator((messageId: number) => {
    const id = Number(messageId);
    if (!Number.isInteger(id) || id < 1) fail("Missing photo.");
    return id;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data: messageId }): Promise<string | null> => {
    const sql = await getSql();
    const me = context.userId;
    const rows = await sql<Row>`select m.image_url from messages m
      join conversations c on c.id = m.conversation_id
      where m.id = ${messageId} and (c.user_a = ${me} or c.user_b = ${me})`;
    return strOrNull(rows[0] ?? {}, "image_url");
  });

export const searchPeople = createServerFn({ method: "GET" })
  .validator((query: string) => query.trim().slice(0, 40).toLowerCase())
  .middleware([authMiddleware])
  .handler(async ({ context, data: query }): Promise<Person[]> => {
    const sql = await getSql();
    const me = context.userId;
    const social = await loadSocial(sql, me);
    const pattern = `%${query.replace(/[%_\\]/g, "\\$&")}%`;
    const rows = await sql<Row>`select * from profiles p
      where p.user_id <> ${me}
        and p.searchable = true
        and not exists (
          select 1 from blocks b
          where (b.user_id = ${me} and b.blocked_id = p.user_id)
             or (b.user_id = p.user_id and b.blocked_id = ${me})
        )
        and (
          ${query} = ''
          or p.username ilike ${pattern} escape '\\'
          or p.display_name ilike ${pattern} escape '\\'
        )
      order by p.last_seen desc
      limit 30`;
    return rows.map((row) => toPerson(row, social, me));
  });

export const getProfile = createServerFn({ method: "GET" })
  .validator((username: string) => username.trim().toLowerCase().slice(0, 24))
  .middleware([authMiddleware])
  .handler(async ({ context, data: username }) => {
    const sql = await getSql();
    const me = context.userId;
    const social = await loadSocial(sql, me);
    const rows = await sql<Row>`select * from profiles where lower(username) = ${username}`;
    const row = rows[0];
    if (!row) return null;
    const userId = str(row, "user_id");
    if (social.blockedMe.has(userId)) return null;
    const person = toPerson(row, social, me);
    const self = userId === me;
    const friends = person.relation === "friends";
    const hidden = !self && !bool(row, "searchable") && !friends;
    if (hidden) return null;
    const policy = str(row, "message_policy");
    const blockedByMe = social.blocked.has(userId);
    const gate = canSendTo(policy, friends || self, blockedByMe);
    return {
      ...person,
      relation: self ? ("none" as const) : person.relation,
      self,
      coverUrl: strOrNull(row, "cover_url"),
      coverRev: num(row, "cover_rev"),
      createdAt: str(row, "created_at"),
      canSend: self ? false : gate.ok,
      sendHint: self ? null : gate.hint,
      blockedByMe,
      friendshipId: self ? null : (social.relation.get(userId)?.id ?? null),
    };
  });

export const requestFriend = createServerFn({ method: "POST" })
  .validator((userId: string) => userId.slice(0, 80))
  .middleware([authMiddleware])
  .handler(async ({ context, data: other }) => {
    const sql = await getSql();
    const me = context.userId;
    if (other === me) fail("That's you.");
    const social = await loadSocial(sql, me);
    if (social.blocked.has(other) || social.blockedMe.has(other)) fail("You can't add this person.");
    const target = await sql<Row>`select user_id, is_guide from profiles where user_id = ${other}`;
    if (!target[0]) fail("That person isn't on Cove.");
    const isGuide = bool(target[0], "is_guide");
    const current = social.relation.get(other);

    const acceptGuide = async (friendshipId: number) => {
      await sql`update friendships set status = 'accepted', updated_at = now() where id = ${friendshipId}`;
      await notify(sql, me, other, "friend_accepted", { friendshipId });
      await postGuideHello(sql, other, me);
    };

    if (!current || current.status === "declined") {
      if (current?.status === "declined") {
        await sql`update friendships set requester_id = ${me}, addressee_id = ${other}, status = ${isGuide ? "accepted" : "pending"}, updated_at = now()
          where id = ${current.id}`;
        if (isGuide) await acceptGuide(current.id);
        else await notify(sql, other, me, "friend_request", { friendshipId: current.id });
        return { ok: true };
      }
      const inserted = await sql<Row>`insert into friendships (requester_id, addressee_id, status)
        values (${me}, ${other}, ${isGuide ? "accepted" : "pending"})
        returning id`;
      const id = num(inserted[0], "id");
      if (isGuide) await acceptGuide(id);
      else await notify(sql, other, me, "friend_request", { friendshipId: id });
      return { ok: true };
    }
    if (current.status === "accepted") return { ok: true };
    if (current.addressee === me) {
      await sql`update friendships set status = 'accepted', updated_at = now() where id = ${current.id}`;
      await notify(sql, other, me, "friend_accepted", { friendshipId: current.id });
      if (isGuide) await postGuideHello(sql, other, me);
      return { ok: true };
    }
    return { ok: true };
  });

export const respondFriend = createServerFn({ method: "POST" })
  .validator((input: { friendshipId: number; accept: boolean }) => {
    const friendshipId = Number(input.friendshipId);
    if (!Number.isInteger(friendshipId)) fail("Missing request.");
    return { friendshipId, accept: Boolean(input.accept) };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = context.userId;
    const rows = await sql<Row>`select * from friendships where id = ${data.friendshipId}`;
    const row = rows[0];
    if (!row || str(row, "addressee_id") !== me) fail("That request isn't yours.");
    if (str(row, "status") !== "pending") return { ok: true };
    const requester = str(row, "requester_id");
    if (data.accept) {
      await sql`update friendships set status = 'accepted', updated_at = now() where id = ${data.friendshipId}`;
      await notify(sql, requester, me, "friend_accepted", { friendshipId: data.friendshipId });
      if (requester.startsWith("guide_")) await postGuideHello(sql, requester, me);
    } else {
      await sql`update friendships set status = 'declined', updated_at = now() where id = ${data.friendshipId}`;
    }
    await sql`update notifications set read = true
      where user_id = ${me} and friendship_id = ${data.friendshipId} and kind = 'friend_request'`;
    return { ok: true };
  });

export const blockPerson = createServerFn({ method: "POST" })
  .validator((userId: string) => userId.slice(0, 80))
  .middleware([authMiddleware])
  .handler(async ({ context, data: other }) => {
    const sql = await getSql();
    if (other === context.userId) fail("You can't block yourself.");
    await sql`insert into blocks (user_id, blocked_id) values (${context.userId}, ${other})
      on conflict do nothing`;
    return { ok: true };
  });

export const unblockPerson = createServerFn({ method: "POST" })
  .validator((userId: string) => userId.slice(0, 80))
  .middleware([authMiddleware])
  .handler(async ({ context, data: other }) => {
    const sql = await getSql();
    await sql`delete from blocks where user_id = ${context.userId} and blocked_id = ${other}`;
    return { ok: true };
  });

export const listBlocked = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Person[]> => {
    const sql = await getSql();
    const me = context.userId;
    const social = await loadSocial(sql, me);
    const rows = await sql<Row>`select p.* from blocks b
      join profiles p on p.user_id = b.blocked_id
      where b.user_id = ${me}
      order by b.created_at desc`;
    return rows.map((row) => toPerson(row, social, me));
  });

async function markDelivered(sql: Sql, me: string) {
  await sql`update messages m set delivered_at = now()
    from conversations c
    where m.conversation_id = c.id
      and (c.user_a = ${me} or c.user_b = ${me})
      and m.sender_id <> ${me}
      and m.delivered_at is null`;
}

export const listConversations = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Conversation[]> => {
    const sql = await getSql();
    const me = context.userId;
    const pending = await sql<Row>`select c.id
      from conversations c
      join profiles p on p.user_id = case when c.user_a = ${me} then c.user_b else c.user_a end
      join lateral (
        select sender_id from messages
        where conversation_id = c.id
        order by id desc
        limit 1
      ) m on true
      where p.is_guide = true
        and m.sender_id = ${me}
        and (c.user_a = ${me} or c.user_b = ${me})`;
    await Promise.all(pending.map((row) => maybeGuideReply(sql, num(row, "id"), me)));
    await markDelivered(sql, me);
    const social = await loadSocial(sql, me);
    const rows = await sql<Row>`select c.id, c.created_at as opened_at, c.created_by,
        p.*,
        m.body, m.image_url, m.created_at as message_at, m.sender_id,
        coalesce(u.unread, 0) as unread,
        t.updated_at as typing_at
      from conversations c
      join profiles p on p.user_id = case when c.user_a = ${me} then c.user_b else c.user_a end
      left join lateral (
        select body, image_url, created_at, sender_id
        from messages where conversation_id = c.id
        order by id desc limit 1
      ) m on true
      left join lateral (
        select count(*) as unread from messages msg
        left join reads r on r.conversation_id = c.id and r.user_id = ${me}
        where msg.conversation_id = c.id
          and msg.sender_id <> ${me}
          and msg.created_at > coalesce(r.last_read_at, '1970-01-01'::timestamptz)
      ) u on true
      left join typing t on t.conversation_id = c.id and t.user_id = p.user_id
        and t.updated_at > now() - interval '3 seconds'
      where (c.user_a = ${me} or c.user_b = ${me})
        and (
          m.created_at is not null
          or c.created_by = ${me}
        )
      order by coalesce(m.created_at, c.created_at) desc`;

    const visible = rows.filter((row) => {
      const id = str(row, "user_id");
      return !social.blocked.has(id) && !social.blockedMe.has(id);
    });
    return visible.map((row) => {
      const image = strOrNull(row, "image_url");
      const body = str(row, "body");
      const preview = body.trim() ? body.trim() : image ? "Photo" : "No messages yet";
      return {
        id: num(row, "id"),
        partner: toPerson(row, social, me),
        preview: preview.length > 90 ? `${preview.slice(0, 88)}…` : preview,
        lastAt: strOrNull(row, "message_at") ?? strOrNull(row, "opened_at"),
        unread: num(row, "unread"),
        typing: Boolean(strOrNull(row, "typing_at")),
        mine: str(row, "sender_id") === me,
      };
    });
  });

export const openConversation = createServerFn({ method: "POST" })
  .validator((userId: string) => userId.slice(0, 80))
  .middleware([authMiddleware])
  .handler(async ({ context, data: other }): Promise<{ conversationId: number }> => {
    const sql = await getSql();
    const me = context.userId;
    if (other === me) fail("Pick someone else to message.");
    const social = await loadSocial(sql, me);
    if (social.blocked.has(other) || social.blockedMe.has(other)) fail("You can't message this person.");
    const rows = await sql<Row>`select * from profiles where user_id = ${other}`;
    if (!rows[0]) fail("That person isn't on Cove.");
    const friends = relationOf(social, other) === "friends";
    const gate = canSendTo(str(rows[0], "message_policy"), friends, false);
    const existing = await sql<Row>`select id from conversations
      where (user_a = ${pair(me, other)[0]} and user_b = ${pair(me, other)[1]})`;
    if (!existing.length && !gate.ok) fail(gate.hint ?? "You can't message this person.");
    const conversationId = await ensureConversation(sql, me, other);
    return { conversationId };
  });

export const getThread = createServerFn({ method: "GET" })
  .validator((conversationId: number) => {
    const id = Number(conversationId);
    if (!Number.isInteger(id) || id < 1) fail("Missing conversation.");
    return id;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data: conversationId }): Promise<Thread | null> => {
    const sql = await getSql();
    const me = context.userId;
    await maybeGuideReply(sql, conversationId, me);
    await markDelivered(sql, me);
    const social = await loadSocial(sql, me);
    const heads = await sql<Row>`select c.id, p.*
      from conversations c
      join profiles p on p.user_id = case when c.user_a = ${me} then c.user_b else c.user_a end
      where c.id = ${conversationId} and (c.user_a = ${me} or c.user_b = ${me})`;
    const head = heads[0];
    if (!head) return null;
    const partnerId = str(head, "user_id");
    if (social.blockedMe.has(partnerId)) return null;
    const messages = await sql<Row>`select id, sender_id, body, image_url, created_at, delivered_at
      from messages where conversation_id = ${conversationId}
      order by id asc
      limit 200`;
    const read = await sql<Row>`select last_read_at from reads
      where conversation_id = ${conversationId} and user_id = ${partnerId}`;
    const typing = await sql<Row>`select updated_at from typing
      where conversation_id = ${conversationId} and user_id = ${partnerId}
        and updated_at > now() - interval '3 seconds'`;
    const partner = toPerson(head, social, me);
    const blockedByMe = social.blocked.has(partnerId);
    const gate = canSendTo(str(head, "message_policy"), partner.relation === "friends", blockedByMe);
    return {
      conversationId,
      partner,
      messages: messages.map((row) => ({
        id: num(row, "id"),
        senderId: str(row, "sender_id"),
        body: str(row, "body"),
        hasImage: Boolean(strOrNull(row, "image_url")),
        createdAt: str(row, "created_at"),
        deliveredAt: strOrNull(row, "delivered_at"),
      })),
      partnerReadAt: strOrNull(read[0] ?? {}, "last_read_at"),
      typing: typing.length > 0,
      canSend: gate.ok,
      sendHint: gate.hint,
      blockedByMe,
    };
  });

export const sendMessage = createServerFn({ method: "POST" })
  .validator((input: { conversationId: number; body: string; image: string | null }) => {
    const conversationId = Number(input.conversationId);
    if (!Number.isInteger(conversationId) || conversationId < 1) fail("Missing conversation.");
    const body = input.body.trim().slice(0, 2000);
    const image = input.image ? cleanImage(input.image, 280_000) : null;
    if (!body && !image) fail("Write a message or attach a photo.");
    return { conversationId, body, image };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = context.userId;
    const heads = await sql<Row>`select p.user_id, p.message_policy, p.is_guide
      from conversations c
      join profiles p on p.user_id = case when c.user_a = ${me} then c.user_b else c.user_a end
      where c.id = ${data.conversationId} and (c.user_a = ${me} or c.user_b = ${me})`;
    if (!heads[0]) fail("That conversation isn't yours.");
    const other = str(heads[0], "user_id");
    const social = await loadSocial(sql, me);
    if (social.blockedMe.has(other)) fail("This conversation isn't available.");
    const gate = canSendTo(
      str(heads[0], "message_policy"),
      relationOf(social, other) === "friends",
      social.blocked.has(other),
    );
    if (!gate.ok) fail(gate.hint ?? "You can't message this person.");
    const inserted = await sql<Row>`insert into messages (conversation_id, sender_id, body, image_url)
      values (${data.conversationId}, ${me}, ${data.body}, ${data.image})
      returning id`;
    await sql`delete from typing where conversation_id = ${data.conversationId} and user_id = ${me}`;
    await notify(sql, other, me, "message", { conversationId: data.conversationId });
    return { id: num(inserted[0], "id") };
  });

export const setTyping = createServerFn({ method: "POST" })
  .validator((input: { conversationId: number; typing: boolean }) => ({
    conversationId: Number(input.conversationId),
    typing: Boolean(input.typing),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = context.userId;
    const ok = await sql<Row>`select id from conversations
      where id = ${data.conversationId} and (user_a = ${me} or user_b = ${me})`;
    if (!ok.length) return { ok: false };
    if (data.typing) {
      await sql`insert into typing (conversation_id, user_id, updated_at)
        values (${data.conversationId}, ${me}, now())
        on conflict (conversation_id, user_id) do update set updated_at = now()`;
    } else {
      await sql`delete from typing where conversation_id = ${data.conversationId} and user_id = ${me}`;
    }
    return { ok: true };
  });

export const markRead = createServerFn({ method: "POST" })
  .validator((conversationId: number) => Number(conversationId))
  .middleware([authMiddleware])
  .handler(async ({ context, data: conversationId }) => {
    const sql = await getSql();
    const me = context.userId;
    const ok = await sql<Row>`select id from conversations
      where id = ${conversationId} and (user_a = ${me} or user_b = ${me})`;
    if (!ok.length) return { ok: false };
    await sql`insert into reads (conversation_id, user_id, last_read_at)
      values (${conversationId}, ${me}, now())
      on conflict (conversation_id, user_id) do update set last_read_at = now()`;
    await sql`update notifications set read = true
      where user_id = ${me} and conversation_id = ${conversationId} and kind = 'message'`;
    return { ok: true };
  });

export const listNotifications = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{ items: Notice[]; unread: number }> => {
    const sql = await getSql();
    const me = context.userId;
    const social = await loadSocial(sql, me);
    const rows = await sql<Row>`select n.id, n.kind, n.read, n.created_at, n.friendship_id, n.conversation_id,
        f.status as friendship_status,
        p.*
      from notifications n
      join profiles p on p.user_id = n.actor_id
      left join friendships f on f.id = n.friendship_id
      where n.user_id = ${me}
      order by n.created_at desc
      limit 60`;
    const items = rows
      .filter((row) => {
        const id = str(row, "user_id");
        return !social.blocked.has(id) && !social.blockedMe.has(id);
      })
      .map((row) => {
        const status = strOrNull(row, "friendship_status");
        return {
          id: num(row, "id"),
          kind: str(row, "kind") as Notice["kind"],
          read: bool(row, "read"),
          createdAt: str(row, "created_at"),
          actor: toPerson(row, social, me),
          friendshipId: row.friendship_id == null ? null : num(row, "friendship_id"),
          friendshipStatus: (status === "pending" || status === "accepted" || status === "declined"
            ? status
            : null) as Notice["friendshipStatus"],
          conversationId: row.conversation_id == null ? null : num(row, "conversation_id"),
        };
      });
    return { items, unread: items.filter((item) => !item.read).length };
  });

export const markNotificationsRead = createServerFn({ method: "POST" })
  .validator((id: number | null) => (id == null ? null : Number(id)))
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    if (id == null) {
      await sql`update notifications set read = true where user_id = ${context.userId} and read = false`;
    } else {
      await sql`update notifications set read = true where user_id = ${context.userId} and id = ${id}`;
    }
    return { ok: true };
  });
