-- Cove profiles, friendships, conversations, and notifications.

create table if not exists profiles (
  user_id text primary key,
  username text not null,
  display_name text not null,
  bio text not null default '',
  avatar_url text,
  avatar_rev integer not null default 0,
  cover_url text,
  cover_rev integer not null default 0,
  hue smallint not null default 0,
  is_guide boolean not null default false,
  setup_done boolean not null default false,
  message_policy text not null default 'everyone' check (message_policy in ('everyone', 'friends')),
  show_online text not null default 'everyone' check (show_online in ('everyone', 'friends', 'nobody')),
  searchable boolean not null default true,
  last_seen timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create unique index if not exists profiles_username_idx on profiles (lower(username));

create table if not exists friendships (
  id serial primary key,
  requester_id text not null,
  addressee_id text not null,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'declined')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists friendships_pair_idx
  on friendships (least(requester_id, addressee_id), greatest(requester_id, addressee_id));

create table if not exists blocks (
  user_id text not null,
  blocked_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, blocked_id)
);

create table if not exists conversations (
  id serial primary key,
  user_a text not null,
  user_b text not null,
  created_by text not null,
  created_at timestamptz not null default now(),
  unique (user_a, user_b)
);

create table if not exists messages (
  id serial primary key,
  conversation_id integer not null references conversations (id) on delete cascade,
  sender_id text not null,
  body text not null default '',
  image_url text,
  created_at timestamptz not null default now(),
  delivered_at timestamptz
);

create index if not exists messages_conversation_idx on messages (conversation_id, id);

create table if not exists reads (
  conversation_id integer not null references conversations (id) on delete cascade,
  user_id text not null,
  last_read_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists typing (
  conversation_id integer not null references conversations (id) on delete cascade,
  user_id text not null,
  updated_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists notifications (
  id serial primary key,
  user_id text not null,
  actor_id text not null,
  kind text not null check (kind in ('friend_request', 'friend_accepted', 'message')),
  friendship_id integer,
  conversation_id integer,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on notifications (user_id, id desc);

insert into profiles (
  user_id, username, display_name, bio, hue, is_guide, setup_done, last_seen
) values
  ('guide_mara', 'mara.vale', 'Mara Vale', 'Keeps a short list of songs worth sending after midnight.', 0, true, true, now()),
  ('guide_jun', 'jun.okada', 'Jun Okada', 'Draws maps of cities he has not visited yet.', 1, true, true, now()),
  ('guide_nia', 'nia.boateng', 'Nia Boateng', 'Runs a plant stall. Half the stock is thriving.', 2, true, true, now()),
  ('guide_cass', 'cass.lin', 'Cass Lin', 'Night owl. Replies faster once the street goes quiet.', 4, true, true, now()),
  ('guide_theo', 'theo.park', 'Theo Park', 'Cooks like the recipe is only a suggestion.', 3, true, true, now() - interval '3 days'),
  ('guide_sable', 'sable.reyes', 'Sable Reyes', 'Editing a novel and one very long voice note.', 5, true, true, now() - interval '2 days')
on conflict (user_id) do nothing;
